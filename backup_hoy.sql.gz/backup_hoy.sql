-- MariaDB dump 10.19-11.8.3-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.3-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `businesses`
--

DROP TABLE IF EXISTS `businesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `businesses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `businesses_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businesses`
--

LOCK TABLES `businesses` WRITE;
/*!40000 ALTER TABLE `businesses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `businesses` VALUES
(1,'Cervecería El Rincón de Pino Montano','cerveceria-el-rincon-de-pino-montano','Las mejores tapas del barrio con un ambiente familiar. Especialidad en montaditos y pescaito frito.','Restauración','Av. de Pino Montano, 42, 41015 Sevilla',37.42610000,-5.96520000,'954 123 456','contacto@elrincondepinomontano.com','https://elrincondepinomontano.ddev.site',NULL,NULL,0,1,'2026-05-29 15:47:25','2026-06-01 06:12:07'),
(2,'Panadería y Pastelería Los Parques','panaderia-y-pasteleria-los-parques','Pan artesano recién hecho cada mañana y repostería tradicional. Tartas por encargo para celebraciones.','Alimentación','Calle Corral de los Olmos, 8, 41015 Sevilla',37.42550000,-5.96400000,'954 987 654','pastelerialosparques@gmail.com',NULL,NULL,NULL,0,1,'2026-05-29 15:47:25','2026-06-01 06:12:07'),
(3,'Talleres Mecánicos Pino Montano','talleres-mecanicos-pino-montano','Tu taller mecánico de confianza. Cambios de aceite, neumáticos, diagnosis de motor y mecánica general multimarca.','Servicios','Calle Corral de la Caridad, 15, 41015 Sevilla',37.42700000,-5.96650000,'654 321 098','info@tallerespinomontano.es','https://tallerespinomontano.es',NULL,NULL,0,1,'2026-05-29 15:47:25','2026-05-30 08:52:00'),
(4,'Peluquería y Estética Sandra','peluqueria-y-estetica-sandra','Cortes de pelo modernos, tintes, tratamientos capilares y estética general. Pide tu cita previa.','Salud y Belleza','Av. de los Parques Alcosa-Pino Montano, 112, 41015 Sevilla',37.42480000,-5.96320000,'954 333 444','sandra@esteticapinomontano.com',NULL,NULL,NULL,0,1,'2026-05-29 15:47:25','2026-06-01 06:12:06'),
(5,'Frutería Hermanos Gómez','fruteria-hermanos-gomez','Frutas y verduras de temporada traídas diariamente. Calidad y frescura directa a tu mesa al mejor precio del barrio.','Alimentación','Calle Corral del Agua, 24, 41015 Sevilla',37.42650000,-5.96200000,'611 222 333','gomezfrutas@hotmail.com',NULL,NULL,NULL,0,1,'2026-05-29 15:47:25','2026-05-30 08:52:00'),
(6,'Ferretería El Tornillo','ferreteria-el-tornillo','Todo lo necesario para bricolaje, fontanería, electricidad y reparaciones del hogar. Duplicado de llaves al instante.','Servicios','Calle Mar de Alborán, 3, 41015 Sevilla',37.42800000,-5.96480000,'954 555 666','eltornillofre@gmail.com',NULL,NULL,NULL,0,1,'2026-05-29 15:47:25','2026-05-30 08:52:00');
/*!40000 ALTER TABLE `businesses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache` VALUES
('laravel-cache-livewire-rate-limiter:e1e88edcf94330bcbe5ea22ba97bb18687ad4318','i:1;',1780299515),
('laravel-cache-livewire-rate-limiter:e1e88edcf94330bcbe5ea22ba97bb18687ad4318:timer','i:1780299515;',1780299515);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_messages`
--

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_05_29_173642_create_businesses_table',1),
(5,'2026_05_29_174416_add_is_approved_to_businesses_table',1),
(6,'2026_05_30_104848_add_coordinates_to_businesses_table',2),
(7,'2026_05_30_104852_create_reviews_table',2),
(8,'2026_05_30_105759_create_contact_messages_table',3),
(9,'2026_05_31_181506_create_social_posts_table',4),
(10,'2026_06_01_073614_make_business_id_nullable_on_social_posts_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint(20) unsigned NOT NULL,
  `author_name` varchar(255) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `comment` text NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_business_id_foreign` (`business_id`),
  CONSTRAINT `reviews_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `reviews` VALUES
(1,3,'asdasd',3,'test 1',1,'2026-06-01 05:39:06','2026-06-01 05:39:06');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sessions` VALUES
('04LdAd3Z6p7M5Zml7zXvjUx6qOcdj4c7j8HWWRhi',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJSeU1uWDFaRGQ2U3NmQ1JjUUw4MUdjT1dwZEdxTVZ1RXpIanlUZzliIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308029),
('0OVZjYREmUoIIhADbfYFMw32BVSuM2huV2bX6TCC',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJLVGR6UWt4VTQ2dmZ3YmloUFNwd1FsUDhVdWlkWjFmeWVXaGFuNUZKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312929),
('1jestUsMLG4wvLZGgikFhbs01x4m9PnlR5QNR2rc',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiIwSHM0enBvSEFNWTdWbnlCRFF1MnNQOGtXVG41cVdlYVZyUVhocElhIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312419),
('1txtpySEqAmtzF5Z4eskjgaVGf9bDEBkjYsxnGBj',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiI5UlRwcmVEMFg2SnRUVURRRjRFM2FnSWk0NmVPRldyQWNHWWtsYURlIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('36cK5XMfLgSd7ES80Auy5MMSyfzy4GN0zlkNSTQI',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJPV21NanVPRFhMS2NkZEhCbEp2ak90S1dITWhqdmxzbkhISVlHeUhNIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312930),
('3Nvath3ohefdiYvsP3D0wsp3Mueh1P5AG5thjNSq',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJlMXBqOFExZWlEa3hIR1lOdjFrR21EZFF1N3M2cjZQbHdnTXVGdm83IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312929),
('4ByeHzP2WbT0ThTIEkfzp5VZipgdKrirvE7jKrgd',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiI3Y25FaXVrZ3JtdjZlUTdjV2NoY1h4R3dSdWtRUWVyYnY1eUpOZlFVIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308007),
('4EdwI0cgkrCruFiOGjRgxdHDF9yiM24v8bjps4Fl',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJuWHlLUU12b0V2WG5jYnZBS1JmdHlVUGZnOWN0WHRhZ0oyQ0tMRkRaIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308030),
('4EZIB32Od2Wn2Hyonrche5E1E8jTyfW9izisIZ3h',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJhSk5JUk56SU0xQVR1ZDNHbHNZNWs1VXQ5Q3ZGU3A0SE83V3FRUkR5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780309665),
('5fzbT9383PMG90NBoCYtqSzYxYM4EXxVOdOteTZa',NULL,'172.18.0.5','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','eyJfdG9rZW4iOiJic2dCc2R4RVdkWU44Y3NLa1NYM1EyZkdTaGp5Tnl4QThsOGpWakFjIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780326502),
('7Yi2TXiXnEegnRN1qiJh9cdHQxuMKtF3RCarXNH8',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJWNmplT2Fnd2N4ckhmWW43b0dRdHNza2RoeWxvTUFxTXF3TzJldUVnIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('8bAOFKLj5XasKiQqE9cu1QGvA774CGyW72LF83xs',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJhOUtTaFB5dWRGaUp4UHluSkNQS01nTktKeUhwa0d1VzBicHY3dUYzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('9gibtn7PMhQdId5fs3EBCmbKeSrC9jXVcHucYGho',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiI4b0JpTFVUUHVmU1lzcjhEWHlnQWhiczNPVW9BYnBNMXRnaEMxcHRmIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780313473),
('AaJ7HU4ModhBHbqOOEYYYkVgGG1KyneFIIKXCFgs',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJkR09VM3FRYkZmd1diWHNvaDNoOUlRTUFDdlRBbkZOOHhjSVpHcGx5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312370),
('Ast5ZedGh0E5KxMQsjMqTtReTnd11X0wilOO0EDX',NULL,'172.18.0.5','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJNTEFhS3drMGNURG96OHNlNE9qa1ZWbzVRZjdVWXJtaTBna21JaXA5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780318835),
('be1WvcNecdCEUQaLpA6kc4c72un5pa6FSWKIgRh3',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJTTUswOUNPb3VPZENrdlFTMmxIV0RjanZ6UjVXRnNLZlBtdWUwVUZKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('bloQTaUOzCQy8WylUq5e7Eb6ikgC4S7ITpT4Kvab',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJyNUd2U1BrcUhSQnJNR0hmcnFWMVRRQjJTWGJteEVxRkRtODNKYkU0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('BzPPmTlFvvDnfxzUZ5zBzONiQkzQl4LvyZfIwJnB',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiIwNDdFc2pvUndYVjB6bm5nbkRiNFZSUHUzZEkwVUxRanp5azhFcVZNIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308013),
('CgwJGHGsyfQjwOjBpg0l0l3RuA4CrQXkGbDEgA7m',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJWNnhXYlo0cDY5RGhodVl2aExLWHZrU2dBYTZrMWRJQWFKYVM4eVhUIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312368),
('CntfIBbSL8TgmVfHGBBRY3KFt71OC8c32m9sdTAt',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJkdnQ2amxHcGozZ1BMTmVWR3hGRmQ4MzduaXd4Qk1xcFlzZklxcjRNIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308018),
('cXjY0KyTAP3Tz0BjRTxjqzUHKC3YFuakFggo8sKW',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJobE90ZXhraFNmenVGNHFTeGIyV0UxWXdFUWR3NTBIRVFySmRxdGhRIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308019),
('DvZ4OJDWhaoRfPx741SfSuJLyCayDNert7Ty72vw',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJLRXpLS3RyRFh3NjVhc1ZOYmY1Q016MDdHRWpkTVVXMmN0bW9sQ1ZKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWVBYzAxdzNtVGpDWnRTckdsMWdZZFR2b0NzUDhOTkdUdGI1Vk5oY0lUc25xa280cFdwSmc4d1BkOVo5NF9hZW1fT20waEhsMl9qamVRb1dqN0RvWVNkQSIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308069),
('FmQOeCzCCSdT1Sa8SO1HDrXIY7Y2837ACWOQQ8Vk',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJ5MWVKc1o4UTdwVnE5Q3E1ZzJZdDBGZUNMZ2JIaXVNYW9MbUNCR1o1IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308013),
('g5HUchTtnDd81OVpatFIOoKQ75Zmx8VXOl7UQ64j',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJnYkFQQ1JNcldIN2FNWnlIU3ZJRVo2dXE5MERwVnJhMGJFYXJXRnhHIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312928),
('gUc72bvFYkctkbc3rnhOXC1xX1RSwld2zuUoFEK3',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiI0ZXkxaEZvRmZMTUtPWnhKVWFZYzFKQTZWREtweVdTYUdXbmE4dE1jIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312935),
('HMqiz1UFyt1Uv5SOlViiNdRCvfYHPCF5iA7PYbFi',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJ2M1RVZGt0VXNUQ1lDR0JqdnlKZkFWWTdSR1JBdWtPcTk1V2NGaFV0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312390),
('HrNr7MSqZk2g1Wd58TwvF15uPmtCPp4dlOPLWkNL',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJ0cEx5VDVTcEZuRlN3NnpNRHAwOTF5NUlPSEkzMXhWMks1VjJlZ2RIIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308023),
('HyqUNIgtSmtjxnwecxSN1tfBqwhhbCywDo8oajW4',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJyUVlvb0poeTRqSzl3UTBDZjZSRDFYN0c0TzRNQXdiaHlRV0VoeUpJIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312933),
('ItMlY9GUXxATAaBt7K5t2aZTAzJJVanKVPMO71uA',NULL,'172.18.0.5','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','eyJfdG9rZW4iOiJ2S1ZkM1FrSWRxS2liUXlUWmd1QTdXeDlkb1RNWTF6emV4eFByamRKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780310385),
('iY7gyPv1JGZSF78aEfF5ZL2mvwsWBsKgCLWUG0PL',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJGZDUzRDZ0OFlpb2c0ZW9SeFBDS3N2a1VWUmIyejlXR3VyNWVHb3lQIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312928),
('KfJK1mNPjmb1EhMzW8dM677kJqkvoVtD1JBPIFja',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJKYlV3TUQzMmxUdjU4SjNsTENZMkJlMTl2ampPRlFJaXNJczVEODFaIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308029),
('kUv3DEDiu33RoDDT79xnEJj5GWleGTL7h5wfdr7w',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJPcE1VT05mSUhNWXdIODJkaFFLVXExUDltR1hFb0h4bVZLNEVvcks4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308029),
('lNllILThq6Ll2YMAzo4Y2XnnEBjv6KcVA1bMB3PU',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJ1MGE0bktjSkZzZjVoNW5RdmJLTlI0OEVHV1Z5Z2pPQXdEb2czdHpuIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('NotNB6uzHq3kBcIPThSIhUQtR0zlVgiHaIItkKrY',2,'172.18.0.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJxd2p1UHFxakZTR1dxeEd2aDJseDRFRUdRRkVhODJjQmxCdFZwSXI5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwidXJsIjpbXSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjIsInBhc3N3b3JkX2hhc2hfd2ViIjoiN2ZhYTk5Y2RkNmVmN2E0MGJjZGE0YWNiZWMwN2IyMjgyY2EwZGYxNTdlNTcyNjM5NjcwMWUzODgxNGFmOGZkOSIsInRhYmxlcyI6eyJkM2Q0MDJiMmZiMzFiNDY1NTA3ZGQ0YzAzNzg2OWQwMV9jb2x1bW5zIjpbeyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6Im5hbWUiLCJsYWJlbCI6IkNvbWVyY2lvIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6ImNhdGVnb3J5IiwibGFiZWwiOiJDYXRlZ29yXHUwMGVkYSIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjp0cnVlLCJpc1RvZ2dsZWFibGUiOmZhbHNlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOm51bGx9LHsidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJwaG9uZSIsImxhYmVsIjoiVGVsXHUwMGU5Zm9ubyIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjp0cnVlLCJpc1RvZ2dsZWFibGUiOmZhbHNlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOm51bGx9LHsidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJlbWFpbCIsImxhYmVsIjoiRW1haWwiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoiaXNfYXBwcm92ZWQiLCJsYWJlbCI6IkFwcm9iYWRvIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6ImlzX2ZlYXR1cmVkIiwibGFiZWwiOiJEZXN0YWNhZG8iLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfV0sImQzZDQwMmIyZmIzMWI0NjU1MDdkZDRjMDM3ODY5ZDAxX3Blcl9wYWdlIjoiMjUifSwiZmlsYW1lbnQiOltdfQ==',1780313053),
('ofJP5B5Oh0QWpj0e2RVF8G1y1UO9yT3X3W9ySKj4',NULL,'172.18.0.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJzZEZzbEFnRkZFT2NlV3R3M0NxMHJLeTZSY1B3aTNVR0lSd3pBcnJiIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780314060),
('PSE6vb4hlxwQtRn0PbgXgyAjjwv9VmL5Plj7rQXF',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJzZWhMR0FlMVFvVDhHSnJuQUZtN2VYVnNoVVlybmkyWkJoQ3dHMnc5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308028),
('qdn0Zja9l17rMcgH9xySWI4gU1Wver7FIiMf9Ox8',NULL,'172.18.0.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJ0eDA5R1I1NFdYVnVia0hZclgwMElKUmVTQU5ucFpKZ2NHVXN0M3RhIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780319634),
('Qr1QIOxBn49ih0II1ijcDZQoTe3ijzeDlIR2Poft',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJKbkFNRmFqWHNlSnJhU0IxNWtEd2hINXBCejZEdU50QWZoU3lSSFdPIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWU1TFd6M0lNemdHYXdncmY2QUxWUmZPcVNEMF84aGtvQ1NCWUJtd1QzYU5sTDdvVFFSNDR1SkxycG02UV9hZW1feFJ2UHEwUVBSUXVaUFdHWkNCWGFXQSIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308067),
('QruxueJ3UC8HI22XgF0Q8W5jtYbYM0Z9VEkVjK1Z',NULL,'172.18.0.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJ6cHF3TERRVkRtUnVPamhQYWJ5Q25sb0dxcGdKNHdBSDJmU0Y1OVBDIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWVBYzAxdzNtVGpDWnRTckdsMWdZZFR2b0NzUDhOTkdUdGI1Vk5oY0lUc25xa280cFdwSmc4d1BkOVo5NF9hZW1fT20waEhsMl9qamVRb1dqN0RvWVNkQSIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308034),
('rFKVQ66qO6NydwE9w9jIBzuFPzqyJQ8mP2go1x68',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJqYmx0aW55cjlPMXRwT1FaVDRMSkwyaGpsMFdyaUZpOVF1VzhaV3E3IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308019),
('Sni6jnxE1mcMEUOBHaRlCiNdoEpPBUQU3KSz4K3Z',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJueGdDNHM2UjY2Z1l4bHdSbU1ubnpjTkJ6R3EySkplMHZTQ2hZeHNRIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780313470),
('T9zPvQMVV7ti0Chpk7rsZURnOF4QBYfeQtZdo1hf',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJZOTlxZHI3cWI2cG9ueXhBcHBQSmV1MUYzT2pMUGFlbjlPdkdBN1liIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780313472),
('Tel70JCKQxpVVHKHbjPtbWyWEr8JU2iIGvlWlXcY',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJXSUhwNE9DSkhCUk1FTnpBUGY0anpYOE1WbmVnUDdRbFVzN3QxSEpEIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312367),
('tH5BSdNHlgO2w5OCluSAe44uIQ7LPaprRquYdfKC',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJZdnNrcm1QWmN6NW5mclk3eUZSZkdZNmdabkJ5Q1JwSjFEUzZ3WXB4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWVuOWZGWEhteFhCNTkyNEJEZ2llQllyb0pGQWJpNDhqb0RIcFM4ZEdHc1FmTllUdEJwOG9DVGpUTWEySV9hZW1fQk1TZV94VlAwTDZoenlJYzJYcFpHUSIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308077),
('TVx9nCBbD2JnSAgoh62Is5p9f2madDGqVgKp9swo',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJYVjVRSGVhRjVZZk42VUpkcXNENmRZejhYV0ZuZUtQRkN1MEV3eDZMIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312389),
('uuvlAXoLIVqES5N14iUjUIDsFTzgtbmtm1ONKxgG',NULL,'172.18.0.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiI4b2pJbnFBcm9QbUN3bUhEa3hRTVJJY01ZalRqUWdBaHllTzRnbFdLIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWU1TFd6M0lNemdHYXdncmY2QUxWUmZPcVNEMF84aGtvQ1NCWUJtd1QzYU5sTDdvVFFSNDR1SkxycG02UV9hZW1feFJ2UHEwUVBSUXVaUFdHWkNCWGFXQSIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308034),
('VTgtfJQRM7RDIyS0PkiFxLktN5U8K1xRz604Ife5',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJORUw5UzNzd3VpODJnRlp2cnVua2h1SE5SRWVOWXVBVm9QWkVnYmxvIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312419),
('Wig3wwGnsafIxePdpEkqFd6DStiuvYWlTTqIV2Hb',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJPWmptREFzSHppY3cxMWNjZ2tLWmdKYWZpejlWckJzbWFqblFiNHgwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780313470),
('wqTYeCi1VGP48t4dhsKibEdvr1W29HEhvI4Nl5TV',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJ1Wm5Semp4c0hvZFFaMTE4SmF0c0JVdkd2SEhjMmRuOEV6dUdyQndCIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWVJYzh5VG12YUlwVWl6ajVMWVpTYjVrRzZCQXpJQmN4WU5LNTFwV0VTOHl3Y1FJLVdxeVpfcEpaSDRIQV9hZW1fdXpzUG01Y0JscTlnUGhkOW5XRVZCZyIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308094),
('WRZ9XLeaxFGErY7JdvYg0hH21CrCCeUZC4TvRGeG',NULL,'172.18.0.5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJzak5hQUJVWU9zV1dSQ2w1MHN2Q01VNUswNUdKRzlhU090eTZHQ2UyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvaGlzdG9yaWEiLCJyb3V0ZSI6ImJhcnJpby5oaXN0b3J5In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312560),
('WWmDcMuD01Q38Dr3xu28FpqWCgHipKaqp1JYanbV',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJiSktEcnpuVmVzOWdCSkJyQXU5SEFMY2E1VXlZd3J6Q1JvSFhSeHIzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780305393),
('X7yht0Wh86SmHSoRUYrjZDnnbJlmU7mLWrxE6AlW',NULL,'172.18.0.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJTSzQ2VG1uZnV2TUhpS1BiUGFQRHRFNjRYZmJFU3BYdnpXTEthU1JWIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vP2ZiY2xpZD1Jd1pYaDBiZ05oWlcwQ01URUFjM0owWXdaaGNIQmZhV1FNTWpVMk1qZ3hNRFF3TlRVNEFBRWVuOWZGWEhteFhCNTkyNEJEZ2llQllyb0pGQWJpNDhqb0RIcFM4ZEdHc1FmTllUdEJwOG9DVGpUTWEySV9hZW1fQk1TZV94VlAwTDZoenlJYzJYcFpHUSIsInJvdXRlIjoiYnVzaW5lc3Muc2hvdyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780308049),
('xLg3Fw1zKdbcZvyY1rf2xhf5I4pXn1TDN1GB6y76',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJGODlzTTBYTHhrTjVreVBNTVpFbXAyMXIxaEhvSUNKMVhpanR0NTN5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308100),
('XSVtvfIjUqsMKZP5wXqME0uFDd058RUzbOCRHCHO',NULL,'172.18.0.5','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','eyJfdG9rZW4iOiI4VHVtMDhOdUFLckRkNU1qdGhPeDBHSkxpbXlWRzdLaHl3djhkaFUwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lcyIsInJvdXRlIjoiZ2VuZXJhdGVkOjp6ZlMweFhKSFh5V25JUnNaIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780319939),
('y8pUfptmk1GivUKcJw4k2HXMT09bmfSkWZY4hfta',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJjbTM2T0lRQlIxcTRXaENwTjBpNm9XMm1UekI2aFB0ODFKZkkySkRvIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780308074),
('zaBklqL4HYOMIFHAlWEzzGtoKo0NsveqtWnBVWPp',NULL,'172.18.0.5','Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJhclk3cnFwMEU4UTdQSFlLcmNZNGliSU93MHJuTVd6c0pqQjc3YTA5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvdW5pcnNlIiwicm91dGUiOiJidXNpbmVzcy5yZWdpc3RlciJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sInVybCI6eyJpbnRlbmRlZCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvYWRtaW4ifX0=',1780305425),
('Zg2XTe1u85G3bmWVuP1EQVCdqLowu4ns1EvqsgrH',NULL,'172.18.0.5','facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)','eyJfdG9rZW4iOiJFNWJia1JtbzRYZVdOdHZRc3p0QzVRMHVWRmVpTVJoM0dLWTRTT1JTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9waW5vbW9udGFuby5lc1wvbmVnb2Npb1wvY2VydmVjZXJpYS1lbC1yaW5jb24tZGUtcGluby1tb250YW5vIiwicm91dGUiOiJidXNpbmVzcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780312934);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `social_posts`
--

DROP TABLE IF EXISTS `social_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint(20) unsigned DEFAULT NULL,
  `platform` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `social_posts_business_id_foreign` (`business_id`),
  CONSTRAINT `social_posts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_posts`
--

LOCK TABLES `social_posts` WRITE;
/*!40000 ALTER TABLE `social_posts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `social_posts` VALUES
(1,1,'x','failed','{\n  \"title\": \"Unauthorized\",\n  \"type\": \"about:blank\",\n  \"status\": 401,\n  \"detail\": \"Unauthorized\"\n}','2026-05-31 16:40:16','2026-05-31 16:40:16'),
(2,1,'x','failed','{\"account_id\":2061151062145298433,\"title\":\"CreditsDepleted\",\"detail\":\"Your enrolled account [2061151062145298433] does not have any credits to fulfill this request.\",\"type\":\"https://api.twitter.com/2/problems/credits\"}','2026-05-31 16:41:00','2026-05-31 16:41:00'),
(3,1,'telegram','failed','{\"ok\":false,\"error_code\":403,\"description\":\"Forbidden: bot is not a member of the channel chat\"}','2026-05-31 17:02:11','2026-05-31 17:02:11'),
(4,1,'telegram','success',NULL,'2026-05-31 17:13:55','2026-05-31 17:13:55'),
(5,1,'facebook','success',NULL,'2026-06-01 08:00:14','2026-06-01 08:00:14'),
(6,1,'instagram','failed','Container creation failed: {\"error\":{\"message\":\"Unsupported post request. Object with ID \'17841400014010579\' does not exist, cannot be loaded due to missing permissions, or does not support this operation. Please read the Graph API documentation at https:\\/\\/developers.facebook.com\\/docs\\/graph-api\",\"type\":\"GraphMethodException\",\"code\":100,\"error_subcode\":33,\"fbtrace_id\":\"A69Cecodna4SicILXjE-WmU\"}}','2026-06-01 08:00:15','2026-06-01 08:00:15');
/*!40000 ALTER TABLE `social_posts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'Test User','test@example.com','2026-05-29 15:47:25','$2y$12$kcGZA7bhjZt2XpgWmFlbhOmd6gF0XLkfeFSc8sN.xTdnWW8VO3a3.','cnCl9mKdBy','2026-05-29 15:47:25','2026-05-29 15:47:25'),
(2,'Admin','admin@pinomontano.es',NULL,'$2y$12$FT047M.DRfGxSD7eBDofp.bpLLoBOXHnjsBGK3B8e5eE7s.QQNABW',NULL,'2026-05-29 15:47:28','2026-05-31 16:28:18');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-06-01 17:10:09
